
# Southern Amusement Company, LLC — Single Page Site

This repository contains a static, host-ready site for GitHub Pages.

## How to publish
1. Create a new GitHub repo (public or private).
2. Upload everything in this folder.
3. In **Settings → Pages**, set:
   - Source: **Deploy from a branch**
   - Branch: **main**, folder: **/ (root)**
4. Wait ~1 minute for Pages to deploy. Your site will appear at `https://<your-username>.github.io/<repo-name>/`.

## Edit content
- `index.html` – main page
- `assets/css/styles.css` – styles
- `assets/images/` – images (logo, photos)

Tip: replace the Vape/ATM placeholders with photos anytime by dropping new images into `assets/images` and updating the `<img>` `src` attributes in `index.html`.
